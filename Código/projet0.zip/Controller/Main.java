import java.util.*;
class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
    Date today = Calendar.getInstance().getTime();
    System.out.println(today);
  }
}